/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 1, 2015, 1:54 AM
 * Purpose: Calculate wholesale and markup for retail price
 */

//System Libraries
#include <iostream>
#include <cstdlib>

using namespace std;

//User Libraries

//Function Prototypes
float coinTos (char);

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    unsigned int number;    //How many times the coin toss should run
    char toss;
    int count = 0;

    //initialize random seed
    srand (time(0));
    
    //Prompt User
    cout<<"How many times would you like to toss the coin?"<<endl;
    cin>>number;
    
    //Coin Toss
    while (count <= number){
        cout<<coinTos(toss)<<endl;
        count++;
    }
    return 0;
}

/****************************************
 ************* coinTos ******************
 ****************************************
 *Purpose: Preform coin toss
 * input: 
 *      toss
 * 
 * output:
 *      toss
 * *************************************/

float coinTos (char toss){
    toss = 0;
    //generate coin flip between 1 and 2
    toss+=(rand() % 2 + 1);
    if(toss==1){
        cout<<"HEADS"<<endl;
    }
    else if(toss==2){
        cout<<"TAILS"<<endl;
    }
    return toss;
}