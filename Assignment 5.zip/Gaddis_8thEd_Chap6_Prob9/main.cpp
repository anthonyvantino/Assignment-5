/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 12, 2015, 8:50 PM
 * Purpose: Calculate savings
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

//User Libraries

//Function Prototypes
float prsVal (float,float,float,float);

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    float presVal;  //Present Value needed to get future value
    float futVal;   //End goal
    float intRate;  //Interest Rate
    float years;    //Years you're willing to let money sit
    
    //Prompt User input
    cout<<"How much would you like in your future account?"<<endl;
    cin>>futVal;
    cout<<"What is the interest rate?"<<endl;
    cin>>intRate;
    cout<<"How many years would you like to let the money sit in the account?"<<endl;
    cin>>years;
    
    //Output
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"For you to get $"<<futVal<<" you will need to deposit $"<<
            prsVal(presVal,futVal,intRate,years)<<endl;
    
    return 0;
}

/***********************************************************************
 ******************************* prsVal ********************************
 ***********************************************************************
 *Purpose:Find how much i will need to put into an account to get 
 *          what i want
 * input:
 *      futVal
 *      intRate
 *      years
 * Output:
 * PresVal
 ***********************************************************************/

float prsVal (float presVal, float futVal, float intRate, float years){
    presVal = futVal / pow((1 + intRate),years);
return presVal;
}
