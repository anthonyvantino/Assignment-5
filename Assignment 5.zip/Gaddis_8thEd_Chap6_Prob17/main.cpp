/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 11, 2015, 11:54 PM
 * Purpose: Calculate population
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Function Prototypes
float Pop (float,float,float,float,float,float,float,int,float,float,float);

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    float n;    //New Population size
    float sp;   //Starting Pop
    float p;    //Previous Pop
    float bp;   //Percentage of births
    float b;    //Births
    float dp;   //Percentage of deaths
    float d;    //Deaths
    float movIn;//People moving in
    float movOut;//People moving out
    float yrs;  //Years to calculate
    int count = 0;
    
    //Prompt user
    cout<<"What was the starting population?"<<endl;
    cin>>sp;
    cout<<"What is the annual birth rate? (Ex: 0.15)"<<endl;
    cin>>bp;
    cout<<"What is the annual death rate? (Ex: 0.15)"<<endl;
    cin>>dp;
    cout<<"How many people move into the area yearly?"<<endl;
    cin>>movIn;
    cout<<"How many people move out of the area yearly?"<<endl;
    cin>>movOut;
    cout<<"How many years do you wish to calculate?"<<endl;
    cin>>yrs;
    
    
    if(sp<2){
        cout<<"Starting Population was too small. Try Again."<<endl;
        if (bp<=0){
            cout<<"Birth Rate was too small. Try Again."<<endl;
            if(dp<=0){
                cout<<"Death Rate was too small. Try Again."<<endl;
                if(movIn<=0){
                    cout<<"Move In rate too small. Try Again."<<endl;
                    if(movOut<=0){
                        cout<<"Move out rate too small. Try Again."<<endl;
                        if(yrs<1){
                            cout<<"Number of years was too small. Try Again."<<endl;
                }
            }
        }
    }
  }
}
    
    //Output
    cout<<fixed<<setprecision(0);
    cout<<"The population after "<<yrs<<" (yrs) will be."<<endl;
    cout<<Pop(n,p,bp,dp,b,d,sp,count,yrs,movIn,movOut)<<endl;
    
    return 0;
}

/***********************************************************************
 ***************************** Population ******************************
 ***********************************************************************
 *Purpose: Calculate population and a number of yrs
 * input:
 * sp
 * bp
 * dp
 * yrs
 * Output:
 * n
 * *******************************************************************/

float Pop (float n,float p,float bp,float dp,float b, float d,float sp,
        int count, float yrs, float movIn, float movOut){ 
    for(count = 0; count < yrs; count++)
        b = sp * bp;
        d = sp * dp;
        p = sp + b - d;
        n = p + bp - dp;
    return n = p + b + movIn - d - movOut;
}
