/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 12, 2015, 8:50 PM
 * Purpose: Calculate savings
 */

//System Libraries
#include <iostream>
#include <cmath>
#include <iomanip>

using namespace std;

//User Libraries

//Function Prototypes
float futrVal (float,float,float,float);

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    float presVal;  //Present Value needed to get future value
    float futVal;   //End goal
    float intRate;  //Interest Rate
    float mnths;    //Months you're willing to let money sit
    
    //Prompt User input
    cout<<"How much do you have in your account currently?"<<endl;
    cin>>presVal;
    cout<<"What is the interest rate?"<<endl;
    cin>>intRate;
    cout<<"How many months would you like to let the money sit in the account?"<<endl;
    cin>>mnths;
    
    //Output
    cout<<fixed<<showpoint<<setprecision(2);
    cout<<"After "<<mnths<<" months you will have $"<<
            futrVal(presVal,futVal,intRate,mnths)<<" total."
            <<endl;
    
    return 0;
}

/***********************************************************************
 ******************************* futrVal ********************************
 ***********************************************************************
 *Purpose:Find how much i will need to put into an account to get 
 *          what i want
 * input:
 *      futVal
 *      intRate
 *      years
 * Output:
 * PresVal
 ***********************************************************************/

float futrVal (float presVal, float futVal, float intRate, float mnths){
    futVal = presVal * pow((1 + intRate),mnths);
return futVal;
}
