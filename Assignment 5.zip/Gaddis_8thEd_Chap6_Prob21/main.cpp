/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 12, 2015, 10:50 PM
 * Purpose: Find out the profit or loss in multiple stock market purchases
 */

//System Libraries
#include <iostream>
#include <iomanip>

using namespace std;

//User Libraries

//Function Prototypes
float  stckPrf1 (float, float, float, float, float, float);
float  stckPrf2 (float, float, float, float, float, float);
//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    float profit1;   //Profit or Loss of the investment
    float ns1;       //Number of Shares
    float sp1;       //Sales Price Per Share
    float sc1;      //Sales commission paid
    float pp1;       //Purchase price per share
    float pc1;       //Purchase Commission Paid
    float profit2;   //Profit or Loss of the investment
    float ns2;       //Number of Shares
    float sp2;       //Sales Price Per Share
    float sc2;      //Sales commission paid
    float pp2;       //Purchase price per share
    float pc2;       //Purchase Commission Paid
    
    //Prompt Input
    cout<<"How many shares are you going to purchase?"<<endl;
    cin>>ns1;
    cout<<"What is the sale price per share?"<<endl;
    cin>>sp1;
    cout<<"What is the sales commission paid?"<<endl;
    cin>>sc1;
    cout<<"What is the purchase price per share?"<<endl;
    cin>>pp1;
    cout<<"What is the price of commission paid?"<<endl;
    cin>>pc1;
    cout<<"Now for the second stock purchase."<<endl;
    cout<<"How many shares are you going to purchase?"<<endl;
    cin>>ns2;
    cout<<"What is the sale price per share?"<<endl;
    cin>>sp2;
    cout<<"What is the sales commission paid?"<<endl;
    cin>>sc2;
    cout<<"What is the purchase price per share?"<<endl;
    cin>>pp2;
    cout<<"What is the price of commission paid?"<<endl;
    cin>>pc2;
    
    //Output
    cout<<fixed<<showpoint<<setprecision(2);
    if (profit1+profit2<=0){
        cout<<"You have lost = $"<<stckPrf1(profit1, ns1, sp1, sc1, pp1, pc1)
                +stckPrf2(profit2, ns2, sp2, sc2, pp2, pc2)<<endl;
    }
    else{
        cout<<"You have made = $"<<stckPrf1(profit1, ns1, sp1, sc1, pp1, pc1)
                +stckPrf2(profit2, ns2, sp2, sc2, pp2, pc2)<<endl;
    }
    
    return 0;
}

/******************************************************************************
 ********************************* stckPrf2 ************************************
 ******************************************************************************
 *Purpose: Calculate profit/loss
 * Input:
 *      ns2
 *      sp2
 *      sc2
 *      pp2
 *      pc2
 * Output:
 *      profit2
 *****************************************************************************/

float stckPrf2 (float profit2, float ns2, float sp2, float sc2, 
        float pp2, float pc2){
    profit2 = ((ns2 * sp2) - sc2) - ((ns2 * pp2) + pc2);
    return profit2;
}

/******************************************************************************
 ********************************* stckPrf1 ************************************
 ******************************************************************************
 *Purpose: Calculate profit/loss
 * Input:
 *      ns1
 *      sp1
 *      sc1
 *      pp1
 *      pc1
 * Output:
 *      profit1
 *****************************************************************************/

float stckPrf1 (float profit1, float ns1, float sp1, float sc1, float pp1,
        float pc1){
    profit1 = ((ns1 * sp1) - sc1) - ((ns1 * pp1) + pc1);
    return profit1;
}