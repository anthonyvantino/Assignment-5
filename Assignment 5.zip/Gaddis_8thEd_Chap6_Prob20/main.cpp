/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 12, 2015, 10:20 PM
 * Purpose: Find out the profit or loss in a stock market purchase
 */

//System Libraries
#include <iostream>
#include <iomanip>

using namespace std;

//User Libraries

//Function Prototypes
float  stckPrf (float, float, float, float, float, float);

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    float profit;   //Profit or Loss of the investment
    float ns;       //Number of Shares
    float sp;       //Sales Price Per Share
    float sc;       //Sales commission paid
    float pp;       //Purchase price per share
    float pc;       //Purchase Commission Paid
    
    //Prompt Input
    cout<<"How many shares are you going to purchase?"<<endl;
    cin>>ns;
    cout<<"What is the sale price per share?"<<endl;
    cin>>sp;
    cout<<"What is the sales commission paid?"<<endl;
    cin>>sc;
    cout<<"What is the purchase price per share?"<<endl;
    cin>>pp;
    cout<<"What is the price of commission paid?"<<endl;
    cin>>pc;
    
    //Output
    cout<<fixed<<showpoint<<setprecision(2);
    if (profit<=0){
        cout<<"You have lost = $"<<stckPrf(profit, ns, sp, sc, pp, pc)<<endl;
    }
    else{
        cout<<"You have made = $"<<stckPrf(profit, ns, sp, sc, pp, pc)<<endl;
    }
    
    return 0;
}

/******************************************************************************
 ********************************* stckPrf ************************************
 ******************************************************************************
 *Purpose: Calculate profit/loss
 * Input:
 *      ns
 *      sp
 *      sc
 *      pp
 *      pc
 * Output:
 *      profit
 *****************************************************************************/

float stckPrf (float profit, float ns, float sp, float sc, float pp, float pc){
    profit = ((ns * sp) - sc) - ((ns * pp) + pc);
    return profit;
}