/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 12, 2015, 12:54 AM
 * Purpose: Find hospital bill costs
 */

//System Libraries
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

//User Libraries

//Function Prototypes
float kEnergy(float,float,float);

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    float kinEn;
    float mass;
    float veloc;
    
    //Prompt User input
    cout<<"What is the objects mass in kilograms."<<endl;
    cin>>mass;
    cout<<"What is the velocity of the object."<<endl;
    cin>>veloc;
    
    //Output
    cout<<"The objects kinetic energy = "<<kEnergy(kinEn,mass,veloc)<<endl;
    
    return 0;
}

float kEnergy (float kinEn, float mass, float veloc){
    kinEn = 0.5 * pow((mass*veloc),2);
    return kinEn;
}