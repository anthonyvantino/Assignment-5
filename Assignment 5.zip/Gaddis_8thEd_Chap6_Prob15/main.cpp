/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 11, 2015, 11:54 PM
 * Purpose: Find hospital bill costs
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Function Prototypes
float inPnt(float,float,float,float,float);
float outPnt(float,float,float);

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    float patient;
    float days;
    float rate;
    float medChrg;
    float hosChrg;
    float total;
    
    //Prompt User Input / Loop
    cout<<"Were you an 'in-patient' or 'out-patient' (enter 1 for in-patient "
            "enter 2 for out-patient"<<endl;
    cin>>patient;
    
    if(patient==1){
        cout<<"How many days were spent in the hospital?"<<endl;
        cin>>days;
        if(days<=0){
            cout<<"Days were too small. Try Again."<<endl;
        }
        cout<<"What was the daily rate?"<<endl;
        cin>>rate;
        if(rate<=0){
            cout<<"Rate was too small. Try Again."<<endl;
        }
        cout<<"How much were the medication charges?"<<endl;
        cin>>medChrg;
        if(medChrg<=0){
            cout<<"Medication Charge too small. Try Again."<<endl;
        }
        cout<<"How much were the hospital service charges?"<<endl;
        cin>>hosChrg;
        if(hosChrg<=0){
            cout<<"Hospital Charges were too small. Try Again."<<endl;
        }
    }
    else if(patient==2){
            cout<<"How much were the hospital service charges?"<<endl;
            cin>>hosChrg;
            if(hosChrg<=0){
            cout<<"Hospital Charges were too small. Try Again."<<endl;
            }
            cout<<"How much were the medication charges?"<<endl;
            cin>>medChrg;
            if(medChrg<=0){
            cout<<"Medication Charge too small. Try Again."<<endl;
            }
        }
    else{
        cout<<"Invalid input."<<endl;
    }
    
    //Output
    cout<<fixed<<showpoint<<setprecision(2);
    if(patient==1){
    cout<<"Hospital Bill Total for In-Patient = $"<<inPnt(days,rate,medChrg,hosChrg,total)<<endl;
    }
    else if(patient==2){
    cout<<"Hospital Bill Total for Out-Patient = $"<<outPnt(hosChrg,medChrg,total)<<endl;
    }
    return 0;
}

float inPnt (float days, float rate, float medChrg, float hosChrg, float total){
    total = (days * rate) + medChrg + hosChrg;
    return total;
}

float outPnt (float hosChrg, float medChrg, float total){
    total = hosChrg + medChrg;
    return total;
}