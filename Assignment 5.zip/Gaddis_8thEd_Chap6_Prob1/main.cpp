/* 
 * File:   main.cpp
 * Author: Anthony Vantino
 * Created on July 1, 2015, 1:54 AM
 * Purpose: Calculate wholesale and markup for retail price
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Function Prototypes
float calRetl (float,float,float,float);

//Execution begins here!
int main(int argc, char** argv) {
    //Declare variables
    float whole;    //Wholesale price
    float markup = 0.0f;   //Markup percent
    float retail;   //Retail price
    float add;      //Whole * markup
    
    //Prompt User input
    cout<<"What was the item's wholesale?"<<endl;
    cin>>whole;
    cout<<"What was the item's markup? (Example, 0.10)"<<endl;
    cin>>markup;
    
    //Loop 
    if (whole<=0){
        cout<<"Invalid input for wholesale. Try again."<<endl;
    }
        if(markup<=0){
            cout<<"Invalid input for markup. Try Again."<<endl;
        }
        else{
        cout<<fixed<<showpoint<<setprecision(2);
        cout<<"The retail price for your item will be = $"<<calRetl
                (whole,markup,retail,add)<<endl;
        }
    return 0;
    }

/*********************************************************************
 **************************** catRetl ********************************
 *********************************************************************
 * input:
 *      whole
 *      markup
 *      retail
 * Output:
 *      add
 *      retail
 ********************************************************************/

float calRetl (float whole, float markup, float retail, float add){
    add = (whole * markup);
    retail = (add + whole);
    return retail;
}
